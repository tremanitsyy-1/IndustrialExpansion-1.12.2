package com.kokorin.industrialexpansion.init;

import com.kokorin.industrialexpansion.IndustrialExpansion;
import com.kokorin.industrialexpansion.item.*;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid=IndustrialExpansion.MODID)
public final class ModItems {
    public static final Item.ToolMaterial INDUSTRIAL_TOOL = EnumHelper.addToolMaterial("INDUSTRIAL_TOOL", 3, 1800, 10.0F, 3.0F, 12);

    public static final Item COPPER_INGOT=new ItemBase("copper_ingot");
    public static final Item TIN_INGOT=new ItemBase("tin_ingot");
    public static final Item BRONZE_INGOT=new ItemBase("bronze_ingot");
    public static final Item COPPER_DUST=new ItemBase("copper_dust");
    public static final Item TIN_DUST=new ItemBase("tin_dust");
    public static final Item IRON_DUST=new ItemBase("iron_dust");
    public static final Item COAL_DUST=new ItemBase("coal_dust");
    public static final Item COPPER_PLATE=new ItemBase("copper_plate");
    public static final Item TIN_PLATE=new ItemBase("tin_plate");
    public static final Item BRONZE_PLATE=new ItemBase("bronze_plate");
    public static final Item CARBON_PLATE=new ItemBase("carbon_plate");
    public static final Item BRONZE_GEAR=new ItemBase("bronze_gear");
    public static final Item COPPER_CABLE=new ItemBase("copper_cable");
    public static final Item INSULATED_COPPER_CABLE=new ItemBase("insulated_copper_cable");
    public static final Item RUBBER=new ItemBase("rubber");
    public static final Item MACHINE_FRAME=new ItemBase("machine_frame");
    public static final Item BASIC_CIRCUIT=new ItemBase("basic_circuit");
    public static final Item ADVANCED_CIRCUIT=new ItemBase("advanced_circuit");
    public static final Item BASIC_BATTERY=new ItemBase("basic_battery");
    public static final Item SOLAR_CELL=new ItemBase("solar_cell");
    public static final Item OVERCLOCKER_UPGRADE=new ItemBase("overclocker_upgrade").setMaxStackSize(16);
    public static final Item ENERGY_UPGRADE=new ItemBase("energy_upgrade").setMaxStackSize(16);
    public static final Item WRENCH=new ItemWrench();
    public static final Item INDUSTRIAL_DRILL=new ItemIndustrialDrill(INDUSTRIAL_TOOL);
    public static final Item ENGINEER_MANUAL=new ItemManual();

    private static final Item[] ALL={COPPER_INGOT,TIN_INGOT,BRONZE_INGOT,COPPER_DUST,TIN_DUST,IRON_DUST,COAL_DUST,COPPER_PLATE,TIN_PLATE,BRONZE_PLATE,CARBON_PLATE,BRONZE_GEAR,COPPER_CABLE,INSULATED_COPPER_CABLE,RUBBER,MACHINE_FRAME,BASIC_CIRCUIT,ADVANCED_CIRCUIT,BASIC_BATTERY,SOLAR_CELL,OVERCLOCKER_UPGRADE,ENERGY_UPGRADE,WRENCH,INDUSTRIAL_DRILL,ENGINEER_MANUAL};
    @SubscribeEvent public static void registerItems(RegistryEvent.Register<Item> e){e.getRegistry().registerAll(ALL);}
    @SubscribeEvent public static void registerModels(ModelRegistryEvent e){for(Item i:ALL)ModelLoader.setCustomModelResourceLocation(i,0,new ModelResourceLocation(i.getRegistryName(),"inventory"));}
}
