package com.kokorin.industrialexpansion.init;

import com.kokorin.industrialexpansion.IndustrialExpansion;
import com.kokorin.industrialexpansion.block.*;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid=IndustrialExpansion.MODID)
public final class ModBlocks {
    public static final Block COPPER_ORE=new BlockBase("copper_ore",Material.ROCK,3F).setResistance(5F);
    public static final Block TIN_ORE=new BlockBase("tin_ore",Material.ROCK,3F).setResistance(5F);
    public static final Block COAL_GENERATOR=new BlockCoalGenerator();
    public static final Block SOLAR_GENERATOR=new BlockSolarGenerator();
    public static final Block BATTERY_BOX=new BlockEnergyStorage();
    public static final Block ENERGY_CABLE=new BlockEnergyCable();
    public static final Block MACERATOR=new BlockMachine("macerator",BlockMachine.Type.MACERATOR);
    public static final Block ELECTRIC_FURNACE=new BlockMachine("electric_furnace",BlockMachine.Type.ELECTRIC_FURNACE);
    public static final Block COMPRESSOR=new BlockMachine("compressor",BlockMachine.Type.COMPRESSOR);
    public static final Block EXTRACTOR=new BlockMachine("extractor",BlockMachine.Type.EXTRACTOR);

    private static final Block[] ALL={COPPER_ORE,TIN_ORE,COAL_GENERATOR,SOLAR_GENERATOR,BATTERY_BOX,ENERGY_CABLE,MACERATOR,ELECTRIC_FURNACE,COMPRESSOR,EXTRACTOR};
    @SubscribeEvent public static void registerBlocks(RegistryEvent.Register<Block> e){e.getRegistry().registerAll(ALL);}
    @SubscribeEvent public static void registerItemBlocks(RegistryEvent.Register<Item> e){for(Block b:ALL)e.getRegistry().register(new ItemBlock(b).setRegistryName(b.getRegistryName()));}
    @SubscribeEvent public static void registerModels(ModelRegistryEvent e){for(Block b:ALL){Item i=Item.getItemFromBlock(b);ModelLoader.setCustomModelResourceLocation(i,0,new ModelResourceLocation(b.getRegistryName(),"inventory"));}}
}
