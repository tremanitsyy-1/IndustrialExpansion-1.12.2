package com.kokorin.industrialexpansion.gui;

import com.kokorin.industrialexpansion.tile.TileCoalGenerator;
import com.kokorin.industrialexpansion.tile.TileProcessingMachine;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.IGuiHandler;

public class GuiHandler implements IGuiHandler {
    public static final int GUI_MACHINE=0, GUI_GENERATOR=1;
    @Override public Object getServerGuiElement(int id,EntityPlayer player,World world,int x,int y,int z){TileEntity te=world.getTileEntity(new BlockPos(x,y,z));if(id==GUI_MACHINE&&te instanceof TileProcessingMachine)return new ContainerMachine(player.inventory,(TileProcessingMachine)te);if(id==GUI_GENERATOR&&te instanceof TileCoalGenerator)return new ContainerGenerator(player.inventory,(TileCoalGenerator)te);return null;}
    @Override public Object getClientGuiElement(int id,EntityPlayer player,World world,int x,int y,int z){TileEntity te=world.getTileEntity(new BlockPos(x,y,z));if(id==GUI_MACHINE&&te instanceof TileProcessingMachine)return new GuiMachine(player.inventory,(TileProcessingMachine)te);if(id==GUI_GENERATOR&&te instanceof TileCoalGenerator)return new GuiGenerator(player.inventory,(TileCoalGenerator)te);return null;}
}
