package com.kokorin.industrialexpansion.gui;

import com.kokorin.industrialexpansion.tile.TileProcessingMachine;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.player.InventoryPlayer;

public class GuiMachine extends GuiContainer {
    private final TileProcessingMachine tile;
    public GuiMachine(InventoryPlayer player, TileProcessingMachine tile) { super(new ContainerMachine(player,tile)); this.tile=tile; xSize=176; ySize=166; }

    @Override protected void drawGuiContainerForegroundLayer(int mouseX,int mouseY){
        fontRenderer.drawString(tile.getMachineName(),8,7,0xE8EEF2);
        fontRenderer.drawString("Энергия",8,57,0xAAB8C2);
        fontRenderer.drawString(tile.getEnergy()+" / "+tile.getMaxEnergy()+" FE",8,68,0xE8C45A);
        fontRenderer.drawString("Ускорители: "+tile.getSpeedUpgrades()+"/4",99,58,0xB9D87A);
        fontRenderer.drawString("Ёмкость: "+tile.getEnergyUpgrades()+"/4",99,69,0x80C7E8);
    }

    @Override protected void drawGuiContainerBackgroundLayer(float partialTicks,int mouseX,int mouseY){
        int x=(width-xSize)/2, y=(height-ySize)/2;
        drawRect(x,y,x+xSize,y+ySize,0xFF20262B);
        drawRect(x+4,y+4,x+xSize-4,y+80,0xFF2E363D);
        drawRect(x+8,y+84,x+xSize-8,y+162,0xFF252C31);
        drawRect(x+42,y+33,x+64,y+55,0xFF111619);
        drawRect(x+114,y+33,x+136,y+55,0xFF111619);
        drawRect(x+68,y+39,x+108,y+49,0xFF151A1E);
        int p=Math.min(38,Math.max(0,tile.getProgressPercent()*38/100));
        drawRect(x+69,y+40,x+69+p,y+48,0xFFE7A63A);
        drawRect(x+8,y+75,x+88,y+80,0xFF12171A);
        int e=tile.getMaxEnergy()==0?0:Math.min(78,tile.getEnergy()*78/tile.getMaxEnergy());
        drawRect(x+9,y+76,x+9+e,y+79,0xFF54B4D6);
        for(int r=0;r<3;r++) for(int c=0;c<9;c++) drawRect(x+7+c*18,y+83+r*18,x+25+c*18,y+101+r*18,0xFF151A1E);
        for(int c=0;c<9;c++) drawRect(x+7+c*18,y+141,x+25+c*18,y+159,0xFF151A1E);
    }
}
