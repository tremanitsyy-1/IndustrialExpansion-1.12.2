package com.kokorin.industrialexpansion.gui;

import com.kokorin.industrialexpansion.tile.TileCoalGenerator;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.player.InventoryPlayer;

public class GuiGenerator extends GuiContainer {
    private final TileCoalGenerator tile;
    public GuiGenerator(InventoryPlayer player,TileCoalGenerator tile){super(new ContainerGenerator(player,tile));this.tile=tile;xSize=176;ySize=166;}
    @Override protected void drawGuiContainerForegroundLayer(int mx,int my){fontRenderer.drawString("Угольный генератор",8,7,0xF0D27A);fontRenderer.drawString("Топливо",68,34,0xB9C0C6);fontRenderer.drawString(tile.getEnergy()+" / "+tile.getMaxEnergy()+" FE",8,68,0xE8C45A);}
    @Override protected void drawGuiContainerBackgroundLayer(float pt,int mx,int my){int x=(width-xSize)/2,y=(height-ySize)/2;drawRect(x,y,x+xSize,y+ySize,0xFF20262B);drawRect(x+4,y+4,x+xSize-4,y+80,0xFF2E363D);drawRect(x+78,y+46,x+100,y+68,0xFF111619);drawRect(x+8,y+75,x+168,y+80,0xFF111619);int e=Math.min(158,tile.getEnergy()*158/tile.getMaxEnergy());drawRect(x+9,y+76,x+9+e,y+79,0xFFFFB43B);int total=tile.getTotalBurnTime();int burn=total<=0?0:Math.min(24,tile.getBurnTime()*24/total);drawRect(x+105,y+64-burn,x+111,y+64,0xFFFF6A35);for(int r=0;r<3;r++)for(int c=0;c<9;c++)drawRect(x+7+c*18,y+83+r*18,x+25+c*18,y+101+r*18,0xFF151A1E);for(int c=0;c<9;c++)drawRect(x+7+c*18,y+141,x+25+c*18,y+159,0xFF151A1E);}
}
