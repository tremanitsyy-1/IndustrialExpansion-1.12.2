package com.kokorin.industrialexpansion.gui;

import com.kokorin.industrialexpansion.tile.TileCoalGenerator;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IContainerListener;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class ContainerGenerator extends Container {
    public final TileCoalGenerator tile;
    private final int[] last = new int[3];
    public ContainerGenerator(InventoryPlayer player, TileCoalGenerator tile) {
        this.tile=tile;
        addSlotToContainer(new Slot(tile,0,80,48));
        for(int r=0;r<3;r++) for(int c=0;c<9;c++) addSlotToContainer(new Slot(player,c+r*9+9,8+c*18,84+r*18));
        for(int c=0;c<9;c++) addSlotToContainer(new Slot(player,c,8+c*18,142));
    }
    @Override public boolean canInteractWith(EntityPlayer playerIn){return tile.isUsableByPlayer(playerIn);}
    @Override public ItemStack transferStackInSlot(EntityPlayer playerIn,int index){return ItemStack.EMPTY;}
    @Override public void detectAndSendChanges(){super.detectAndSendChanges();for(int id=0;id<3;id++){int v=tile.getField(id);if(v!=last[id]){for(IContainerListener l:listeners)l.sendWindowProperty(this,id,v);last[id]=v;}}}
    @Override public void updateProgressBar(int id,int data){tile.setField(id,data);}
}
