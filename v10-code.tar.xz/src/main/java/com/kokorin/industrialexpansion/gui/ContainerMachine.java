package com.kokorin.industrialexpansion.gui;

import com.kokorin.industrialexpansion.tile.TileProcessingMachine;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IContainerListener;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class ContainerMachine extends Container {
    public final TileProcessingMachine tile;
    private final int[] last = new int[6];

    public ContainerMachine(InventoryPlayer player, TileProcessingMachine tile) {
        this.tile = tile;
        addSlotToContainer(new Slot(tile, 0, 44, 35));
        addSlotToContainer(new Slot(tile, 1, 116, 35) { @Override public boolean isItemValid(ItemStack stack) { return false; } });
        for (int r=0;r<3;r++) for(int c=0;c<9;c++) addSlotToContainer(new Slot(player, c+r*9+9, 8+c*18, 84+r*18));
        for (int c=0;c<9;c++) addSlotToContainer(new Slot(player, c, 8+c*18, 142));
    }

    @Override public boolean canInteractWith(EntityPlayer playerIn) { return tile.isUsableByPlayer(playerIn); }
    @Override public ItemStack transferStackInSlot(EntityPlayer playerIn, int index) { return ItemStack.EMPTY; }

    @Override public void detectAndSendChanges() {
        super.detectAndSendChanges();
        for (int id=0; id<6; id++) {
            int v=tile.getField(id);
            if (v!=last[id]) { for(IContainerListener l:listeners) l.sendWindowProperty(this,id,v); last[id]=v; }
        }
    }
    @Override public void updateProgressBar(int id, int data) { tile.setField(id,data); }
}
