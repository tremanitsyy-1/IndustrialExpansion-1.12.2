package com.kokorin.industrialexpansion.tile;

import com.kokorin.industrialexpansion.init.ModItems;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class TileExtractor extends TileProcessingMachine {
    @Override public String getMachineName() { return "Экстрактор"; }
    @Override protected int baseEnergyPerTick() { return 14; }
    @Override protected int baseWorkTime() { return 90; }
    @Override protected ItemStack getRecipeResult(ItemStack in) {
        if (in.isEmpty()) return ItemStack.EMPTY;
        Item item = in.getItem();
        if (item == Items.SLIME_BALL) return new ItemStack(ModItems.RUBBER, 4);
        if (item == Item.getItemFromBlock(Blocks.LOG) || item == Item.getItemFromBlock(Blocks.LOG2)) return new ItemStack(ModItems.RUBBER, 2);
        return ItemStack.EMPTY;
    }
}
