package com.kokorin.industrialexpansion.tile;
public class TileBatteryBox extends TileEnergyNode {
    @Override protected int capacity() { return 250000; }
    @Override protected int transferRate() { return 240; }
}
