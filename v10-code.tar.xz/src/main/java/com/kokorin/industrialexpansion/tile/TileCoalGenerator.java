package com.kokorin.industrialexpansion.tile;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntityFurnace;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;

public class TileCoalGenerator extends TileEnergyNode implements IInventory {
    private int burnTime;
    private int totalBurnTime;
    private ItemStack fuel = ItemStack.EMPTY;

    @Override protected int capacity() { return 120000; }
    @Override protected int transferRate() { return 160; }

    @Override protected void beforeTransfer() {
        if (burnTime <= 0 && !fuel.isEmpty()) {
            int value = TileEntityFurnace.getItemBurnTime(fuel);
            if (value > 0) {
                burnTime = value;
                totalBurnTime = value;
                fuel.shrink(1);
                if (fuel.getCount() <= 0) fuel = ItemStack.EMPTY;
                markDirty();
            }
        }
        if (burnTime > 0 && energy < capacity()) {
            burnTime--;
            energy = Math.min(capacity(), energy + 28);
            markDirty();
        }
    }

    public boolean tryInsertFuel(ItemStack stack) {
        if (stack.isEmpty() || TileEntityFurnace.getItemBurnTime(stack) <= 0) return false;
        if (fuel.isEmpty()) { fuel = stack.copy(); fuel.setCount(1); markDirty(); return true; }
        if (ItemStack.areItemsEqual(fuel, stack) && fuel.getCount() < fuel.getMaxStackSize()) { fuel.grow(1); markDirty(); return true; }
        return false;
    }
    public int getBurnTime() { return burnTime; }
    public int getTotalBurnTime() { return totalBurnTime; }

    @Override public NBTTagCompound writeToNBT(NBTTagCompound c) { super.writeToNBT(c); c.setInteger("BurnTime", burnTime); c.setInteger("TotalBurnTime", totalBurnTime); if (!fuel.isEmpty()) c.setTag("Fuel", fuel.writeToNBT(new NBTTagCompound())); return c; }
    @Override public void readFromNBT(NBTTagCompound c) { super.readFromNBT(c); burnTime = c.getInteger("BurnTime"); totalBurnTime = c.getInteger("TotalBurnTime"); fuel = c.hasKey("Fuel") ? new ItemStack(c.getCompoundTag("Fuel")) : ItemStack.EMPTY; }

    @Override public int getSizeInventory() { return 1; }
    @Override public boolean isEmpty() { return fuel.isEmpty(); }
    @Override public ItemStack getStackInSlot(int index) { return index == 0 ? fuel : ItemStack.EMPTY; }
    @Override public ItemStack decrStackSize(int index, int count) { if (index != 0 || fuel.isEmpty()) return ItemStack.EMPTY; ItemStack r = fuel.splitStack(count); if (fuel.getCount() <= 0) fuel = ItemStack.EMPTY; markDirty(); return r; }
    @Override public ItemStack removeStackFromSlot(int index) { if (index != 0) return ItemStack.EMPTY; ItemStack r = fuel; fuel = ItemStack.EMPTY; markDirty(); return r; }
    @Override public void setInventorySlotContents(int index, ItemStack stack) { if (index == 0) { fuel = stack; markDirty(); } }
    @Override public int getInventoryStackLimit() { return 64; }
    @Override public boolean isUsableByPlayer(EntityPlayer player) { return world != null && world.getTileEntity(pos) == this && player.getDistanceSq(pos) <= 64.0D; }
    @Override public void openInventory(EntityPlayer player) { }
    @Override public void closeInventory(EntityPlayer player) { }
    @Override public boolean isItemValidForSlot(int index, ItemStack stack) { return index == 0 && TileEntityFurnace.getItemBurnTime(stack) > 0; }
    @Override public int getField(int id) { if (id == 0) return energy; if (id == 1) return burnTime; if (id == 2) return totalBurnTime; return 0; }
    @Override public void setField(int id, int value) { if (id == 0) energy = value; else if (id == 1) burnTime = value; else if (id == 2) totalBurnTime = value; }
    @Override public int getFieldCount() { return 3; }
    @Override public void clear() { fuel = ItemStack.EMPTY; }
    @Override public String getName() { return "Угольный генератор"; }
    @Override public boolean hasCustomName() { return true; }
    @Override public ITextComponent getDisplayName() { return new TextComponentString(getName()); }
}
