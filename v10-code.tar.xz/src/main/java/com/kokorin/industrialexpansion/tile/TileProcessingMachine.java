package com.kokorin.industrialexpansion.tile;

import com.kokorin.industrialexpansion.energy.IEnergyMachine;
import com.kokorin.industrialexpansion.init.ModItems;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;

public abstract class TileProcessingMachine extends TileEntity implements ITickable, IEnergyMachine, IInventory {
    protected int energy;
    protected int progress;
    protected int speedUpgrades;
    protected int energyUpgrades;
    protected ItemStack input = ItemStack.EMPTY;
    protected ItemStack output = ItemStack.EMPTY;

    protected int baseCapacity() { return 30000; }
    protected int baseEnergyPerTick() { return 18; }
    protected int baseWorkTime() { return 100; }
    protected abstract ItemStack getRecipeResult(ItemStack input);
    public abstract String getMachineName();

    public int getWorkTime() { return Math.max(20, baseWorkTime() - speedUpgrades * 15); }
    public int getEnergyPerTick() { return baseEnergyPerTick() + speedUpgrades * 8; }
    @Override public int getMaxEnergy() { return baseCapacity() + energyUpgrades * 20000; }

    @Override
    public void update() {
        if (world == null || world.isRemote) return;
        ItemStack result = getRecipeResult(input);
        int use = getEnergyPerTick();
        if (!input.isEmpty() && !result.isEmpty() && canOutput(result) && energy >= use) {
            energy -= use;
            progress++;
            if (progress >= getWorkTime()) {
                input.shrink(1);
                if (input.getCount() <= 0) input = ItemStack.EMPTY;
                if (output.isEmpty()) output = result.copy(); else output.grow(result.getCount());
                progress = 0;
                markDirty();
            }
        } else if (progress > 0) {
            progress = Math.max(0, progress - 1);
        }
    }

    protected boolean canOutput(ItemStack result) {
        return output.isEmpty() || (ItemStack.areItemsEqual(output, result) && output.getCount() + result.getCount() <= output.getMaxStackSize());
    }

    public boolean insertInput(ItemStack stack) {
        if (stack.isEmpty()) return false;
        ItemStack one = stack.copy(); one.setCount(1);
        if (getRecipeResult(one).isEmpty()) return false;
        if (input.isEmpty()) input = one;
        else if (ItemStack.areItemsEqual(input, one) && input.getCount() < input.getMaxStackSize()) input.grow(1);
        else return false;
        markDirty();
        return true;
    }

    public ItemStack takeOutput() { if (output.isEmpty()) return ItemStack.EMPTY; ItemStack r = output.copy(); output = ItemStack.EMPTY; markDirty(); return r; }
    public int getProgressPercent() { return getWorkTime() <= 0 ? 0 : progress * 100 / getWorkTime(); }
    public int getProgressTicks() { return progress; }
    public int getSpeedUpgrades() { return speedUpgrades; }
    public int getEnergyUpgrades() { return energyUpgrades; }

    public boolean installUpgrade(ItemStack held) {
        if (held.isEmpty()) return false;
        if (held.getItem() == ModItems.OVERCLOCKER_UPGRADE && speedUpgrades < 4) { speedUpgrades++; markDirty(); return true; }
        if (held.getItem() == ModItems.ENERGY_UPGRADE && energyUpgrades < 4) { energyUpgrades++; markDirty(); return true; }
        return false;
    }

    @Override public int receiveEnergy(int amount) { int a = Math.min(Math.max(0, amount), getMaxEnergy() - energy); energy += a; if (a > 0) markDirty(); return a; }
    @Override public int extractEnergy(int amount) { int e = Math.min(Math.max(0, amount), energy); energy -= e; if (e > 0) markDirty(); return e; }
    @Override public int getEnergy() { return energy; }

    @Override public NBTTagCompound writeToNBT(NBTTagCompound c) {
        super.writeToNBT(c); c.setInteger("Energy", energy); c.setInteger("Progress", progress); c.setInteger("SpeedUpgrades", speedUpgrades); c.setInteger("EnergyUpgrades", energyUpgrades);
        if (!input.isEmpty()) c.setTag("Input", input.writeToNBT(new NBTTagCompound()));
        if (!output.isEmpty()) c.setTag("Output", output.writeToNBT(new NBTTagCompound()));
        return c;
    }
    @Override public void readFromNBT(NBTTagCompound c) {
        super.readFromNBT(c); energy = c.getInteger("Energy"); progress = c.getInteger("Progress"); speedUpgrades = c.getInteger("SpeedUpgrades"); energyUpgrades = c.getInteger("EnergyUpgrades");
        input = c.hasKey("Input") ? new ItemStack(c.getCompoundTag("Input")) : ItemStack.EMPTY;
        output = c.hasKey("Output") ? new ItemStack(c.getCompoundTag("Output")) : ItemStack.EMPTY;
    }

    @Override public int getSizeInventory() { return 2; }
    @Override public boolean isEmpty() { return input.isEmpty() && output.isEmpty(); }
    @Override public ItemStack getStackInSlot(int index) { return index == 0 ? input : index == 1 ? output : ItemStack.EMPTY; }
    @Override public ItemStack decrStackSize(int index, int count) {
        ItemStack stack = getStackInSlot(index); if (stack.isEmpty()) return ItemStack.EMPTY;
        ItemStack result = stack.splitStack(count); if (stack.getCount() <= 0) setInventorySlotContents(index, ItemStack.EMPTY); markDirty(); return result;
    }
    @Override public ItemStack removeStackFromSlot(int index) { ItemStack s = getStackInSlot(index); setInventorySlotContents(index, ItemStack.EMPTY); return s; }
    @Override public void setInventorySlotContents(int index, ItemStack stack) { if (index == 0) input = stack; else if (index == 1) output = stack; markDirty(); }
    @Override public int getInventoryStackLimit() { return 64; }
    @Override public boolean isUsableByPlayer(EntityPlayer player) { return world != null && world.getTileEntity(pos) == this && player.getDistanceSq(pos) <= 64.0D; }
    @Override public void openInventory(EntityPlayer player) { }
    @Override public void closeInventory(EntityPlayer player) { }
    @Override public boolean isItemValidForSlot(int index, ItemStack stack) { return index == 0 && !getRecipeResult(stack).isEmpty(); }
    @Override public int getField(int id) { if (id == 0) return energy; if (id == 1) return getMaxEnergy(); if (id == 2) return progress; if (id == 3) return getWorkTime(); if (id == 4) return speedUpgrades; if (id == 5) return energyUpgrades; return 0; }
    @Override public void setField(int id, int value) { if (id == 0) energy = value; else if (id == 2) progress = value; else if (id == 4) speedUpgrades = value; else if (id == 5) energyUpgrades = value; }
    @Override public int getFieldCount() { return 6; }
    @Override public void clear() { input = ItemStack.EMPTY; output = ItemStack.EMPTY; }
    @Override public String getName() { return getMachineName(); }
    @Override public boolean hasCustomName() { return true; }
    @Override public ITextComponent getDisplayName() { return new TextComponentString(getMachineName()); }
}
