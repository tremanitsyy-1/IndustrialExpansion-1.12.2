package com.kokorin.industrialexpansion.tile;
public class TileEnergyCable extends TileEnergyNode {
    @Override protected int capacity() { return 4000; }
    @Override protected int transferRate() { return 120; }
}
