package com.kokorin.industrialexpansion.tile;

import com.kokorin.industrialexpansion.init.ModBlocks;
import com.kokorin.industrialexpansion.init.ModItems;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class TileMacerator extends TileProcessingMachine {
    @Override public String getMachineName() { return "Дробитель"; }
    @Override protected int baseEnergyPerTick() { return 20; }
    @Override protected int baseWorkTime() { return 100; }
    @Override protected ItemStack getRecipeResult(ItemStack in) {
        if (in.isEmpty()) return ItemStack.EMPTY;
        Item item = in.getItem();
        if (item == Item.getItemFromBlock(ModBlocks.COPPER_ORE)) return new ItemStack(ModItems.COPPER_DUST, 2);
        if (item == Item.getItemFromBlock(ModBlocks.TIN_ORE)) return new ItemStack(ModItems.TIN_DUST, 2);
        if (item == Item.getItemFromBlock(Blocks.IRON_ORE)) return new ItemStack(ModItems.IRON_DUST, 2);
        if (item == ModItems.COPPER_INGOT) return new ItemStack(ModItems.COPPER_DUST);
        if (item == ModItems.TIN_INGOT) return new ItemStack(ModItems.TIN_DUST);
        if (item == Items.IRON_INGOT) return new ItemStack(ModItems.IRON_DUST);
        if (item == Items.COAL) return new ItemStack(ModItems.COAL_DUST, 2);
        return ItemStack.EMPTY;
    }
}
