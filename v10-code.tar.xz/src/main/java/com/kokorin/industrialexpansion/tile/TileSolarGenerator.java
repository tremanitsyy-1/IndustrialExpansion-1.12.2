package com.kokorin.industrialexpansion.tile;
public class TileSolarGenerator extends TileEnergyNode {
    @Override protected int capacity() { return 50000; }
    @Override protected int transferRate() { return 80; }
    @Override protected void beforeTransfer() {
        if (world != null && world.isDaytime() && world.canSeeSky(pos.up()) && !world.isRainingAt(pos.up())) {
            energy = Math.min(capacity(), energy + 12);
            markDirty();
        }
    }
}
