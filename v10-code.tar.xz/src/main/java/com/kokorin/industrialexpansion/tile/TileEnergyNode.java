package com.kokorin.industrialexpansion.tile;

import com.kokorin.industrialexpansion.energy.IEnergyMachine;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;

public abstract class TileEnergyNode extends TileEntity implements ITickable, IEnergyMachine {
    protected int energy;

    protected abstract int capacity();
    protected abstract int transferRate();

    protected void beforeTransfer() { }

    @Override
    public void update() {
        if (world == null || world.isRemote) return;
        beforeTransfer();
        if (energy <= 0) return;
        for (EnumFacing side : EnumFacing.values()) {
            TileEntity te = world.getTileEntity(pos.offset(side));
            if (te instanceof IEnergyMachine && te != this) {
                int sent = ((IEnergyMachine) te).receiveEnergy(Math.min(transferRate(), energy));
                energy -= sent;
                if (sent > 0) markDirty();
                if (energy <= 0) break;
            }
        }
    }

    @Override public int receiveEnergy(int amount) { int accepted = Math.min(Math.max(0, amount), capacity() - energy); energy += accepted; if (accepted > 0) markDirty(); return accepted; }
    @Override public int extractEnergy(int amount) { int extracted = Math.min(Math.max(0, amount), energy); energy -= extracted; if (extracted > 0) markDirty(); return extracted; }
    @Override public int getEnergy() { return energy; }
    @Override public int getMaxEnergy() { return capacity(); }
    @Override public NBTTagCompound writeToNBT(NBTTagCompound c) { super.writeToNBT(c); c.setInteger("Energy", energy); return c; }
    @Override public void readFromNBT(NBTTagCompound c) { super.readFromNBT(c); energy = c.getInteger("Energy"); }
}
