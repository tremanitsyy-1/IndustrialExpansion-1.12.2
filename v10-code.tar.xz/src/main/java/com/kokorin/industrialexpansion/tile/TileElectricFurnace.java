package com.kokorin.industrialexpansion.tile;

import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.FurnaceRecipes;

public class TileElectricFurnace extends TileProcessingMachine {
    @Override public String getMachineName() { return "Электропечь"; }
    @Override protected int baseEnergyPerTick() { return 16; }
    @Override protected int baseWorkTime() { return 75; }
    @Override protected ItemStack getRecipeResult(ItemStack in) {
        if (in.isEmpty()) return ItemStack.EMPTY;
        ItemStack result = FurnaceRecipes.instance().getSmeltingResult(in);
        return result.isEmpty() ? ItemStack.EMPTY : result.copy();
    }
}
