package com.kokorin.industrialexpansion.tile;

import com.kokorin.industrialexpansion.init.ModItems;
import net.minecraft.item.ItemStack;

public class TileCompressor extends TileProcessingMachine {
    @Override public String getMachineName() { return "Компрессор"; }
    @Override protected int baseEnergyPerTick() { return 24; }
    @Override protected int baseWorkTime() { return 120; }
    @Override protected ItemStack getRecipeResult(ItemStack in) {
        if (in.isEmpty()) return ItemStack.EMPTY;
        if (in.getItem() == ModItems.COPPER_INGOT) return new ItemStack(ModItems.COPPER_PLATE);
        if (in.getItem() == ModItems.TIN_INGOT) return new ItemStack(ModItems.TIN_PLATE);
        if (in.getItem() == ModItems.BRONZE_INGOT) return new ItemStack(ModItems.BRONZE_PLATE);
        if (in.getItem() == ModItems.COAL_DUST) return new ItemStack(ModItems.CARBON_PLATE);
        return ItemStack.EMPTY;
    }
}
