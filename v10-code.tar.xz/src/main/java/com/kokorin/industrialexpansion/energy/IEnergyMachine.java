package com.kokorin.industrialexpansion.energy;

public interface IEnergyMachine {
    int receiveEnergy(int amount);
    int extractEnergy(int amount);
    int getEnergy();
    int getMaxEnergy();
}
