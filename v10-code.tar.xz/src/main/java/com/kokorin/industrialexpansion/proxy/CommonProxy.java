package com.kokorin.industrialexpansion.proxy;

public class CommonProxy {
    public void registerModels() { }
}
