package com.kokorin.industrialexpansion.proxy;

public class ClientProxy extends CommonProxy {
}
