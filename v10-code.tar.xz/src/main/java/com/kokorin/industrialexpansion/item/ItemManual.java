package com.kokorin.industrialexpansion.item;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;

public class ItemManual extends ItemBase {
    public ItemManual(){super("engineer_manual");setMaxStackSize(1);}
    @Override public ActionResult<ItemStack> onItemRightClick(World world,EntityPlayer player,EnumHand hand){
        ItemStack s=player.getHeldItem(hand);
        if(!world.isRemote){
            player.sendMessage(new TextComponentString("§6§lIndustrial Expansion — справочник инженера"));
            player.sendMessage(new TextComponentString("§7Энергия: генератор/солнечная панель → кабель → аккумулятор/машина."));
            player.sendMessage(new TextComponentString("§7Дробитель удваивает медную, оловянную и железную руду."));
            player.sendMessage(new TextComponentString("§7Компрессор делает пластины и углепластик. Экстрактор добывает резину."));
            player.sendMessage(new TextComponentString("§7ПКМ по машине открывает интерфейс. Улучшение ставится ПКМ по машине предметом."));
            player.sendMessage(new TextComponentString("§7Shift+ПКМ ключом снимает технику без долгой ломки."));
        }
        return new ActionResult<>(EnumActionResult.SUCCESS,s);
    }
}
