package com.kokorin.industrialexpansion.item;

import com.kokorin.industrialexpansion.IndustrialExpansion;
import net.minecraft.item.Item;

public class ItemBase extends Item {
    public ItemBase(String name) {
        setRegistryName(IndustrialExpansion.MODID, name);
        setTranslationKey(IndustrialExpansion.MODID + "." + name);
        setCreativeTab(IndustrialExpansion.TAB);
    }
}
