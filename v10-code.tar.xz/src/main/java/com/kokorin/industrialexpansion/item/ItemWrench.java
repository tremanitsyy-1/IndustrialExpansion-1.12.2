package com.kokorin.industrialexpansion.item;

import com.kokorin.industrialexpansion.IndustrialExpansion;
import com.kokorin.industrialexpansion.init.ModBlocks;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class ItemWrench extends ItemBase {
    public ItemWrench(){super("wrench");setMaxStackSize(1);setMaxDamage(256);}
    @Override public EnumActionResult onItemUse(EntityPlayer player,World world,BlockPos pos,EnumHand hand,EnumFacing facing,float hitX,float hitY,float hitZ){
        if(world.isRemote)return EnumActionResult.SUCCESS;
        Block b=world.getBlockState(pos).getBlock();
        if(!player.isSneaking()) return EnumActionResult.PASS;
        if(b==ModBlocks.COPPER_ORE||b==ModBlocks.TIN_ORE) return EnumActionResult.PASS;
        if(b.getRegistryName()==null||!IndustrialExpansion.MODID.equals(b.getRegistryName().getNamespace())) return EnumActionResult.PASS;
        Item drop=Item.getItemFromBlock(b); if(drop==null) return EnumActionResult.PASS;
        world.setBlockToAir(pos);
        if(!player.addItemStackToInventory(new ItemStack(drop))) player.dropItem(new ItemStack(drop),false);
        player.getHeldItem(hand).damageItem(1,player);
        return EnumActionResult.SUCCESS;
    }
}
