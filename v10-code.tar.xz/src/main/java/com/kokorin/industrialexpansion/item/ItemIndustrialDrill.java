package com.kokorin.industrialexpansion.item;

import com.kokorin.industrialexpansion.IndustrialExpansion;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPickaxe;

public class ItemIndustrialDrill extends ItemPickaxe {
    public ItemIndustrialDrill(Item.ToolMaterial material) {
        super(material); setRegistryName(IndustrialExpansion.MODID,"industrial_drill"); setTranslationKey(IndustrialExpansion.MODID+".industrial_drill"); setCreativeTab(IndustrialExpansion.TAB); setMaxStackSize(1);
    }
}
