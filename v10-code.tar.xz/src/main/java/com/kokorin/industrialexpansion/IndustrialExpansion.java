package com.kokorin.industrialexpansion;

import com.kokorin.industrialexpansion.gui.GuiHandler;
import com.kokorin.industrialexpansion.init.ModBlocks;
import com.kokorin.industrialexpansion.init.ModItems;
import com.kokorin.industrialexpansion.proxy.CommonProxy;
import com.kokorin.industrialexpansion.tile.*;
import com.kokorin.industrialexpansion.world.WorldGenCopper;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod(modid = IndustrialExpansion.MODID, name = IndustrialExpansion.NAME, version = IndustrialExpansion.VERSION)
public class IndustrialExpansion {
    public static final String MODID = "industrialexpansion";
    public static final String NAME = "Industrial Expansion";
    public static final String VERSION = "1.0.0";

    @Mod.Instance(MODID)
    public static IndustrialExpansion INSTANCE;

    @SidedProxy(clientSide = "com.kokorin.industrialexpansion.proxy.ClientProxy", serverSide = "com.kokorin.industrialexpansion.proxy.CommonProxy")
    public static CommonProxy PROXY;

    public static final CreativeTabs TAB = new CreativeTabs(MODID) {
        @Override public ItemStack createIcon() { return new ItemStack(ModItems.BASIC_CIRCUIT); }
    };

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        GameRegistry.registerTileEntity(TileCoalGenerator.class, MODID + ":coal_generator");
        GameRegistry.registerTileEntity(TileSolarGenerator.class, MODID + ":solar_generator");
        GameRegistry.registerTileEntity(TileBatteryBox.class, MODID + ":battery_box");
        GameRegistry.registerTileEntity(TileEnergyCable.class, MODID + ":energy_cable");
        GameRegistry.registerTileEntity(TileMacerator.class, MODID + ":macerator");
        GameRegistry.registerTileEntity(TileElectricFurnace.class, MODID + ":electric_furnace");
        GameRegistry.registerTileEntity(TileCompressor.class, MODID + ":compressor");
        GameRegistry.registerTileEntity(TileExtractor.class, MODID + ":extractor");
        GameRegistry.registerWorldGenerator(new WorldGenCopper(), 0);
        NetworkRegistry.INSTANCE.registerGuiHandler(INSTANCE, new GuiHandler());
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        GameRegistry.addSmelting(ModBlocks.COPPER_ORE, new ItemStack(ModItems.COPPER_INGOT), 0.7F);
        GameRegistry.addSmelting(ModBlocks.TIN_ORE, new ItemStack(ModItems.TIN_INGOT), 0.7F);
        GameRegistry.addSmelting(ModItems.COPPER_DUST, new ItemStack(ModItems.COPPER_INGOT), 0.4F);
        GameRegistry.addSmelting(ModItems.TIN_DUST, new ItemStack(ModItems.TIN_INGOT), 0.4F);
        GameRegistry.addSmelting(ModItems.IRON_DUST, new ItemStack(net.minecraft.init.Items.IRON_INGOT), 0.4F);
    }
}
