package com.kokorin.industrialexpansion.block;

import com.kokorin.industrialexpansion.IndustrialExpansion;
import com.kokorin.industrialexpansion.gui.GuiHandler;
import com.kokorin.industrialexpansion.tile.TileCoalGenerator;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import javax.annotation.Nullable;

public class BlockCoalGenerator extends BlockContainer {
    public BlockCoalGenerator() { super(Material.IRON); setRegistryName(IndustrialExpansion.MODID,"coal_generator"); setTranslationKey(IndustrialExpansion.MODID+".coal_generator"); setCreativeTab(IndustrialExpansion.TAB); setHardness(4F); setResistance(10F); }
    @Override public boolean onBlockActivated(World world, BlockPos pos, IBlockState state, EntityPlayer player, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
        if (!world.isRemote) player.openGui(IndustrialExpansion.INSTANCE, GuiHandler.GUI_GENERATOR, world, pos.getX(), pos.getY(), pos.getZ()); return true;
    }
    @Override public void breakBlock(World world, BlockPos pos, IBlockState state) { TileEntity te=world.getTileEntity(pos); if(te instanceof TileCoalGenerator) InventoryHelper.dropInventoryItems(world,pos,(TileCoalGenerator)te); super.breakBlock(world,pos,state); }
    @Nullable @Override public TileEntity createNewTileEntity(World worldIn,int meta){return new TileCoalGenerator();}
}
