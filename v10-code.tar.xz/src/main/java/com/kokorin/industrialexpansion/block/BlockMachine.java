package com.kokorin.industrialexpansion.block;

import com.kokorin.industrialexpansion.IndustrialExpansion;
import com.kokorin.industrialexpansion.gui.GuiHandler;
import com.kokorin.industrialexpansion.tile.*;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import javax.annotation.Nullable;

public class BlockMachine extends BlockContainer {
    public enum Type { MACERATOR, ELECTRIC_FURNACE, COMPRESSOR, EXTRACTOR }
    private final Type type;

    public BlockMachine(String name, Type type) {
        super(Material.IRON); this.type = type;
        setRegistryName(IndustrialExpansion.MODID, name); setTranslationKey(IndustrialExpansion.MODID + "." + name); setCreativeTab(IndustrialExpansion.TAB); setHardness(4F); setResistance(10F);
    }

    @Override
    public boolean onBlockActivated(World world, BlockPos pos, IBlockState state, EntityPlayer player, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
        if (world.isRemote) return true;
        TileEntity te = world.getTileEntity(pos);
        if (!(te instanceof TileProcessingMachine)) return false;
        TileProcessingMachine m = (TileProcessingMachine) te;
        ItemStack held = player.getHeldItem(hand);
        if (!held.isEmpty() && m.installUpgrade(held)) {
            if (!player.capabilities.isCreativeMode) held.shrink(1);
            player.sendMessage(new TextComponentString("§aУлучшение установлено §8| §7Скорость: §e" + m.getSpeedUpgrades() + "/4 §8| §7Энергия: §e" + m.getEnergyUpgrades() + "/4"));
            return true;
        }
        player.openGui(IndustrialExpansion.INSTANCE, GuiHandler.GUI_MACHINE, world, pos.getX(), pos.getY(), pos.getZ());
        return true;
    }

    @Override public void breakBlock(World world, BlockPos pos, IBlockState state) {
        TileEntity te = world.getTileEntity(pos); if (te instanceof TileProcessingMachine) InventoryHelper.dropInventoryItems(world, pos, (TileProcessingMachine) te); super.breakBlock(world, pos, state);
    }

    @Nullable @Override public TileEntity createNewTileEntity(World worldIn, int meta) {
        switch (type) {
            case ELECTRIC_FURNACE: return new TileElectricFurnace();
            case COMPRESSOR: return new TileCompressor();
            case EXTRACTOR: return new TileExtractor();
            default: return new TileMacerator();
        }
    }
}
