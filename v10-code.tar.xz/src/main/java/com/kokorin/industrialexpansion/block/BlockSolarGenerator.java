package com.kokorin.industrialexpansion.block;

import com.kokorin.industrialexpansion.IndustrialExpansion;
import com.kokorin.industrialexpansion.tile.TileSolarGenerator;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import javax.annotation.Nullable;

public class BlockSolarGenerator extends BlockContainer {
    public BlockSolarGenerator() { super(Material.IRON); setRegistryName(IndustrialExpansion.MODID, "solar_generator"); setTranslationKey(IndustrialExpansion.MODID + ".solar_generator"); setCreativeTab(IndustrialExpansion.TAB); setHardness(3F); setResistance(8F); }
    @Override public boolean onBlockActivated(World w, BlockPos p, IBlockState s, EntityPlayer pl, EnumHand h, EnumFacing f, float x, float y, float z) {
        if (!w.isRemote) { TileEntity te=w.getTileEntity(p); if(te instanceof TileSolarGenerator){TileSolarGenerator g=(TileSolarGenerator)te; boolean active=w.isDaytime()&&w.canSeeSky(p.up())&&!w.isRainingAt(p.up()); pl.sendMessage(new TextComponentString("§3Солнечный генератор §8| §7Энергия: §e"+g.getEnergy()+"/"+g.getMaxEnergy()+" FE §8| "+(active?"§aГенерация 12 FE/t":"§cНет солнца")));}} return true;
    }
    @Nullable @Override public TileEntity createNewTileEntity(World worldIn, int meta) { return new TileSolarGenerator(); }
}
