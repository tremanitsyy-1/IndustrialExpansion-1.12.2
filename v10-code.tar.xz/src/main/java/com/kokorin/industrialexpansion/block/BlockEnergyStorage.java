package com.kokorin.industrialexpansion.block;

import com.kokorin.industrialexpansion.IndustrialExpansion;
import com.kokorin.industrialexpansion.tile.TileBatteryBox;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import javax.annotation.Nullable;

public class BlockEnergyStorage extends BlockContainer {
    public BlockEnergyStorage() { super(Material.IRON); setRegistryName(IndustrialExpansion.MODID, "battery_box"); setTranslationKey(IndustrialExpansion.MODID + ".battery_box"); setCreativeTab(IndustrialExpansion.TAB); setHardness(4F); setResistance(12F); }
    @Override public boolean onBlockActivated(World w, BlockPos p, IBlockState s, EntityPlayer pl, EnumHand h, EnumFacing f, float x, float y, float z) {
        if (!w.isRemote) { TileEntity te = w.getTileEntity(p); if (te instanceof TileBatteryBox) { TileBatteryBox b=(TileBatteryBox)te; pl.sendMessage(new TextComponentString("§bЭнергохранилище §8| §7Энергия: §e"+b.getEnergy()+"§7/§e"+b.getMaxEnergy()+" FE")); } } return true;
    }
    @Nullable @Override public TileEntity createNewTileEntity(World worldIn, int meta) { return new TileBatteryBox(); }
}
