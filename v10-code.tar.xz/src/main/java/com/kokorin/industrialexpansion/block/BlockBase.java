package com.kokorin.industrialexpansion.block;

import com.kokorin.industrialexpansion.IndustrialExpansion;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class BlockBase extends Block {
    public BlockBase(String name, Material material, float hardness) {
        super(material);
        setRegistryName(IndustrialExpansion.MODID, name);
        setTranslationKey(IndustrialExpansion.MODID + "." + name);
        setCreativeTab(IndustrialExpansion.TAB);
        setHardness(hardness);
    }
}
