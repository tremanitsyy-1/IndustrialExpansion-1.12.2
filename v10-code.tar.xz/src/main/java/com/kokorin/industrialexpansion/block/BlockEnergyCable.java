package com.kokorin.industrialexpansion.block;

import com.kokorin.industrialexpansion.IndustrialExpansion;
import com.kokorin.industrialexpansion.tile.TileEnergyCable;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;
import javax.annotation.Nullable;

public class BlockEnergyCable extends BlockContainer {
    public BlockEnergyCable() {
        super(Material.IRON); setRegistryName(IndustrialExpansion.MODID, "energy_cable"); setTranslationKey(IndustrialExpansion.MODID + ".energy_cable"); setCreativeTab(IndustrialExpansion.TAB); setHardness(1.2F); setResistance(3F);
    }
    @Nullable @Override public TileEntity createNewTileEntity(World worldIn, int meta) { return new TileEnergyCable(); }
}
