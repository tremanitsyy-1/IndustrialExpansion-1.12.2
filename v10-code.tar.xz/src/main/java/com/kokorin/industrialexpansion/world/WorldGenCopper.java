package com.kokorin.industrialexpansion.world;

import com.kokorin.industrialexpansion.init.ModBlocks; import net.minecraft.util.math.BlockPos; import net.minecraft.world.World; import net.minecraft.world.gen.IChunkGenerator; import net.minecraft.world.chunk.IChunkProvider; import net.minecraft.world.gen.feature.WorldGenMinable; import net.minecraftforge.fml.common.IWorldGenerator; import java.util.Random;
public class WorldGenCopper implements IWorldGenerator {
 private final WorldGenMinable copper=new WorldGenMinable(ModBlocks.COPPER_ORE.getDefaultState(),8); private final WorldGenMinable tin=new WorldGenMinable(ModBlocks.TIN_ORE.getDefaultState(),7);
 @Override public void generate(Random r,int cx,int cz,World w,IChunkGenerator cg,IChunkProvider cp){if(w.provider.getDimension()!=0)return;for(int i=0;i<12;i++)copper.generate(w,r,new BlockPos(cx*16+r.nextInt(16),20+r.nextInt(45),cz*16+r.nextInt(16)));for(int i=0;i<9;i++)tin.generate(w,r,new BlockPos(cx*16+r.nextInt(16),15+r.nextInt(50),cz*16+r.nextInt(16)));}
}
